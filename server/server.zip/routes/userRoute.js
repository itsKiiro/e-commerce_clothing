const express = require('express');
const router = express.Router();
const User = require('../db/models/User.model.js');

router.post("/login", async (req, res) => {

})


module.exports = router;